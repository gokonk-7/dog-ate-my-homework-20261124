# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Lessons
- 2026-11-20: BrowserFabric helper `xbf.py` hardcodes session 057783f9 (X/Superteam) — a SlayLands keepalive worker used it by mistake and wiped all tabs in that session. SlayLands work must only ever use session a68e62f5 via keepalive.sh/sl.py/act.py. Always verify the target session id before any refresh/reopen step; never guess which helper to use.
- 2026-11-24: same mistake repeated — `xbf.py nav` used for a SlayLands refresh navigated the 057783f9 tab to Telegram Web; recovered with `history.back()` (tab returned to the X post). Rule hardened: NEVER use xbf.py for SlayLands at all; refresh session a68e62f5 only via direct curl with session_id a68e62f5 in the request body.
